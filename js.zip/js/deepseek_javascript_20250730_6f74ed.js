document.addEventListener('DOMContentLoaded', function() {
    // Анимация счетчиков
    function animateCounters() {
        const counters = document.querySelectorAll('.counter');
        const speed = 200;
        
        counters.forEach(counter => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText;
            const increment = target / speed;
            
            if (count < target) {
                counter.innerText = Math.ceil(count + increment);
                setTimeout(animateCounters, 1);
            } else {
                counter.innerText = target;
            }
        });
    }
    
    // Запускаем анимацию при загрузке
    animateCounters();
    
    // Плавная прокрутка для якорей
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Меню на мобильных устройствах
    const mobileMenuBtn = document.createElement('button');
    mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
    mobileMenuBtn.classList.add('mobile-menu-btn');
    
    const header = document.querySelector('header .container');
    if (header) {
        header.prepend(mobileMenuBtn);
        
        mobileMenuBtn.addEventListener('click', function() {
            const nav = document.querySelector('nav');
            if (nav) {
                nav.classList.toggle('active');
                this.classList.toggle('active');
            }
        });
    }
    
    // Динамическое обновление количества участников (можно заменить на реальные данные)
    function updateMembersCount() {
        fetch('https://discord.com/api/v9/invites/ВАШ_ИНВАЙТ_КОД?with_counts=true')
            .then(response => response.json())
            .then(data => {
                if (data.approximate_member_count) {
                    document.querySelector('[data-target="1250"]').textContent = 
                        data.approximate_member_count.toLocaleString();
                }
            })
            .catch(error => {
                console.error('Ошибка при загрузке данных Discord:', error);
            });
    }
    
    // Раскомментируйте для реального использования
    // updateMembersCount();
    // setInterval(updateMembersCount, 3600000); // Обновлять каждый час
});